refSeqs = 
[
   {
      "length" : 50001,
      "name" : "ctgA",
      "seqDir" : "seq/ctgA",
      "seqChunkSize" : 20000,
      "end" : 50001,
      "start" : 0
   }
]
