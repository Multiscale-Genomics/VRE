define(['dojo/_base/declare'],function(declare) {

return declare(null,

/**
 * @lends JBrowse.View.TrackList.Null.prototype
 */
{
    setTracksActive: function() {},
    setTracksInactive: function() {},
    show: function() {},
    hide: function() {},
    toggle: function() {}
});
});

